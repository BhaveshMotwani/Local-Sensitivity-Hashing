output.txt is the correct answer for this test case.
wrong.txt is the answer if we take 4 bands, with each 5 values in each band, which is WRONG for this homework. But you could use this to help you test your solution.
